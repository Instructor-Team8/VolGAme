const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

canvas.width = 800;
canvas.height = 600;

// Создаем объект машинки
const car = {
  x: 50,
  y: 250,
  width: 50,
  height: 50,
  speed: 5,
  score: 0,
};

// Создаем массив объектов для сбора
const objects = [];

// Обработчик нажатий на клавиши
const keys = {};

document.addEventListener("keydown", (e) => {
  keys[e.key] = true;
});

document.addEventListener("keyup", (e) => {
  keys[e.key] = false;
});

// Функция для создания нового объекта
function createObject() {
  const object = {
    x: canvas.width,
    y: Math.random() * (canvas.height - 50), // чтобы объект не выходил за границы поля
    width: 50,
    height: 50,
  };

  objects.push(object);
}
// Функция для отображения машинки на холсте
function drawImage() {
  const carImage = new Image();
  carImage.src = "car.jpg";
  ctx.drawImage(carImage, car.x, car.y, car.width, car.height);
}

// Функция для отображения объектов на холсте
function drawObjects() {
  objects.forEach((object) => {
    ctx.fillStyle = "red";
    ctx.fillRect(object.x, object.y, object.width, object.height);
  });
}

// Функция для проверки столкновения машинки и объекта
function checkCollision(object) {
  if (
    car.x < object.x + object.width &&
    car.x + car.width > object.x &&
    car.y < object.y + object.height &&
    car.y + car.height > object.y
  ) {
    car.score++;
    const index = objects.indexOf(object);
    objects.splice(index, 1);
  }
}

// Функция для обновления игровых данных
function update() {
  if (frame % 50 === 0) {
    createObject();
  }

  objects.forEach(checkCollision);

  if (keys["ArrowUp"]) {
    car.y -= car.speed;
  }

  if (keys["ArrowDown"]) {
    car.y += car.speed;
  }

  if (keys["ArrowLeft"]) {
    car.x -= car.speed;
  }

  if (keys["ArrowRight"]) {
    car.x += car.speed;
  }

  drawImage();

  drawObjects();

  ctx.font = "30px Arial";
  ctx.fillStyle = "black";
  ctx.fillText(`Score: ${car.score}`, 10, 50);

  frame++;
}

let frame = 0;

function loop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  update();

  requestAnimationFrame(loop);
}

loop();