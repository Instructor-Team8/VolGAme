// Инициализация переменных
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var tileSize = 80;
var width = canvas.width / tileSize;
var height = canvas.height / tileSize;
var score = 0;
var gameOver = false;

/// Создание змейки
var snake = [];
snake[0] = {
x: Math.floor(width / 2),
y: Math.floor(height / 2),
};
var direction;

// Проверка на длину змейки
if (snake.length != 1) {
gameOver = true;
}
// Создание еды
var food = {
  x: Math.floor(Math.random() * width),
  y: Math.floor(Math.random() * height),
};

// Управление змейкой
document.addEventListener("keydown", function (event) {
  if (event.keyCode == 37 && direction != "right") {
    direction = "left";
  } else if (event.keyCode == 38 && direction != "down") {
    direction = "up";
  } else if (event.keyCode == 39 && direction != "left") {
    direction = "right";
  } else if (event.keyCode == 40 && direction != "up") {
    direction = "down";
  }
});

// Обновление экрана
function draw() {
    // Проверка на Game Over
    if (gameOver) {
    ctx.fillStyle = "red";
    ctx.font = "50px Arial";
    ctx.fillText("Game Over!", 80, canvas.height / 2);

    var img = new Image();
    img.onload = function() {
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    }
    img.src = "1.jpeg";
    return;
    }
  // Обновление позиции змейки
  var headX = snake[0].x;
  var headY = snake[0].y;

  if (direction == "left") headX--;
  else if (direction == "up") headY--;
  else if (direction == "right") headX++;
  else if (direction == "down") headY++;

  // Проверка на столкновение со стеной или собственным телом
  if (
    headX < 0 ||
    headY < 0 ||
    headX >= width ||
    headY >= height ||
    checkCollision(headX, headY, snake)
  ) {
    gameOver = true;
  }

  // Проверка на съедение еды
  if (headX == food.x && headY == food.y) {
    score++;
    food = {
      x: Math.floor(Math.random() * width),
      y: Math.floor(Math.random() * height),
    };
    snake.pop();
  } else {
    snake.pop();
  }

  // Добавление нового элемента в змейку
  var newHead = {
    x: headX,
    y: headY,
  };

  snake.unshift(newHead);

  // Отрисовка поля
  ctx.clearRect(0, 0, canvas.width, canvas.height);

// Отрисовка еды
// Отрисовка еды
var pizzaImg = new Image();
pizzaImg.src = 'pointniva1.png';
pizzaImg.onload = function() {
    ctx.drawImage(pizzaImg, food.x * tileSize, food.y * tileSize, tileSize, tileSize);
  }
// Отрисовка змейки
// Отрисовка змейки
for (var i = 0; i < snake.length; i++) {
    var img = new Image();
    img.src = "car.png";
    ctx.drawImage(img, snake[i].x * tileSize, snake[i].y * tileSize, tileSize, tileSize);
  }

// Отрисовка счета
ctx.fillStyle = "black";
ctx.font = "20px Arial";
ctx.fillText("НИВА №" + score, 10, canvas.height - 10);

// Вызов функции через определенный интервал времени
setTimeout(draw, 100);
}

// Проверка на столкновение с телом змейки
function checkCollision(x, y, array) {
for (var i = 0; i < array.length; i++) {
  if (array[i].x == x && array[i].y == y) {
    return false;
  }
}
return false;
}

// Вызов функции обновления экрана
draw();
